from django.shortcuts import *
from django.contrib.auth import authenticate,login
from django.contrib.auth.models import User
from .models import *
from datetime import date
from django.http import *
import datetime

#---------------------------------------------------Signup-----------------------------------------------------------
def index(request):
	if request.method == 'POST':
		user=User()
		user.username=request.POST.get('username')
		user.email=request.POST.get('email')
		user.password=request.POST.get('password')
		user.save()
		template = loader.get_template('login.html')
    		context = {'success':1,'name':request.POST.get('username')}
		return HttpResponse(template.render(context, request))
	else:
		success=0	
		template = loader.get_template('register.html')
    		context = {}
		return HttpResponse(template.render(context, request))

#------------------------------------------Home page----------------------------------------------------------
def home(request):
	template = loader.get_template('navbar.html')
    	context = {}
	return HttpResponse(template.render(context, request))

#--------------------------------------------Login------------------------------------------------------------
def login(request):
	if request.method == 'POST':
		try:
			user=User.objects.get(username=request.POST.get('username'),password=request.POST.get('password'))
			request.session['username']=request.POST.get('username')
			template = loader.get_template('categories.html')
    			context = {'success':1,'name':request.session['username']}
			return HttpResponse(template.render(context, request))	
		except:
			template = loader.get_template('login.html')
    			context = {'success':0}
			return HttpResponse(template.render(context, request))				
	else:
		template = loader.get_template('login.html')
    		context = {}
		return HttpResponse(template.render(context, request))

#------------------------Saving into respective tables taken from the user through forms-------------------------------

def category(request):
	today=date.today()
	#print today	
	if request.method == 'POST':
		print request.session['username']
		#if request.POST.get('grocery'):
		if request.POST.get('dropdown')=="Grocery":
			g=Grocery(user=request.session['username'],grocery_expense_date=request.POST.get('spentdate'),spent_money=request.POST.get('spentmoney'))
			g.save()
			
		elif request.POST.get('dropdown')=="Entertainment":
		#elif request.POST.get('entertainment'):
			e=Entertainment(user=request.session['username'],entertainment_expense_date=request.POST.get('spentdate'),spent_money=request.POST.get('spentmoney'))
			e.save()

		elif request.POST.get('dropdown')=="Education":
		#elif request.POST.get('education'):
			edu=Education(user=request.session['username'],education_expense_date=request.POST.get('spentdate'),spent_money=request.POST.get('spentmoney'))
			edu.save()
			
		elif request.POST.get('dropdown')=="Vehicle":
		#elif request.POST.get('vehicle'):
			v=Vehicle(user=request.session['username'],vehicle_expense_date=request.POST.get('spentdate'),spent_money=request.POST.get('spentmoney'))
			v.save()
			
		elif request.POST.get('dropdown')=="Food":
		#elif request.POST.get('food'):
			f=Food(user=request.session['username'],food_expense_date=request.POST.get('spentdate'),spent_money=request.POST.get('spentmoney'))
			f.save()
			
		elif request.POST.get('dropdown')=="Parties":
			p=Parties(user=request.session['username'],parties_expense_date=request.POST.get('spentdate'),spent_money=request.POST.get('spentmoney'))
			p.save()
			
		else:
			m=Miscellaneous(user=request.session['username'],miscellaneous_expense_date=request.POST.get('spentdate'),spent_money=request.POST.get('spentmoney'))
			m.save()
	template = loader.get_template('categories.html')
	context = {'name':request.session['username']}
	return HttpResponse(template.render(context, request))

#-------------------List of all expenses for each individual user and saving into respective tables-----------------------

def expenseslist(request):
	#Getting objects for every table
	g=Grocery.objects.all()
	e=Entertainment.objects.all()
	edu=Education.objects.all()
	f=Food.objects.all()
	v=Vehicle.objects.all()
	p=Parties.objects.all()
	m=Miscellaneous.objects.all()
	#Initializing every categorie's amount to 0
	g_money=0
	e_money=0
	edu_money=0
	f_money=0
	v_money=0
	p_money=0
	m_money=0
	total_money=0
	#Adding expenses to the particular user
	for person in g:
		if person.user==request.session['username']:
			g_money=g_money+person.spent_money

	for person in e:
		if person.user==request.session['username']:
			e_money=e_money+person.spent_money

	for person in edu:
		if person.user==request.session['username']:
			edu_money=edu_money+person.spent_money

	for person in f:
		if person.user==request.session['username']:
			f_money=f_money+person.spent_money

	for person in v:
		if person.user==request.session['username']:
			v_money=v_money+person.spent_money

	for person in p:
		if person.user==request.session['username']:
			p_money=p_money+person.spent_money

	for person in m:
		if person.user==request.session['username']:
			m_money=m_money+person.spent_money
	#Total amount spent by a person		
	total_money=g_money+e_money+edu_money+v_money+p_money+f_money+m_money

	template = loader.get_template('expense_list.html')
	context = {'grocery_money':g_money,'entertainment_money':e_money,'education_money':edu_money,'name':request.session['username'],'food_money':f_money,'vehicle_money':v_money,'parties_money':p_money,'miscellaneous_money':m_money,'total':total_money}
	return HttpResponse(template.render(context, request))

#-----------------------Monthly Expenditures for each individual---------------------------------

def monthlyreport(request):
#Getting table's objects
	g=Grocery.objects.all()
	e=Entertainment.objects.all()
	edu=Education.objects.all()
	f=Food.objects.all()
	v=Vehicle.objects.all()
	p=Parties.objects.all()
	m=Miscellaneous.objects.all()
#Initializing every categories amount
	g_money=0
	e_money=0
	edu_money=0
	f_money=0
	v_money=0
	p_money=0
	m_money=0
	total_money=0
	#today1=date.today()
#Adding expenses to the particular user on monthly bases
	today = datetime.datetime.now().strftime ("%Y-%m-%d")
	year,month,date=today.split('-')
	#print str(person.grocery_expense_date)

	for person in g:
		if person.user==request.session['username']:
			spent_date=str(person.grocery_expense_date)
			spent_year,spent_month,expense_date=spent_date.split('-')
			#Checking if today's month and the month on which the individual has spent the amount are equal.
			if spent_month==month and spent_year==year:
				g_money=g_money+person.spent_money

	for person in e:
		if person.user==request.session['username']:
			spent_date=str(person.entertainment_expense_date)
			spent_year,spent_month,expense_date=spent_date.split('-')
			if spent_month==month and spent_year==year:
				e_money=e_money+person.spent_money

	for person in edu:
		if person.user==request.session['username']:
			spent_date=str(person.education_expense_date)
			spent_year,spent_month,expense_date=spent_date.split('-')
			if spent_month==month and spent_year==year:
				edu_money=edu_money+person.spent_money

	for person in f:
		if person.user==request.session['username']:
			spent_date=str(person.food_expense_date)
			spent_year,spent_month,expense_date=spent_date.split('-')
			if spent_month==month and spent_year==year:
				f_money=f_money+person.spent_money
	for person in v:
		if person.user==request.session['username']:
			spent_date=str(person.vehicle_expense_date)
			spent_year,spent_month,expense_date=spent_date.split('-')
			if spent_month==month and spent_year==year:
				v_money=v_money+person.spent_money
	for person in p:
		if person.user==request.session['username']:
			spent_date=str(person.parties_expense_date)
			spent_year,spent_month,expense_date=spent_date.split('-')
			if spent_month==month and spent_year==year:
				p_money=p_money+person.spent_money
	for person in m:
		if person.user==request.session['username']:
			spent_date=str(person.miscellaneous_expense_date)
			spent_year,spent_month,expense_date=spent_date.split('-')
			if spent_month==month and spent_year==year:
				m_money=m_money+person.spent_money
	
	total_money=g_money+e_money+edu_money+v_money+p_money+f_money+m_money

	template = loader.get_template('monthlyreport.html')
	context ={'grocery_money':g_money,'entertainment_money':e_money,'education_money':edu_money,'food_money':f_money,'vehicle_money':v_money,'parties_money':p_money,'miscellaneous_money':m_money,'name':request.session['username'],'total':total_money,'month':month}
	return HttpResponse(template.render(context, request))
	
#--------------------------------------Daily Expenditures for each individual----------------------------------------------------
def dailyreport(request):
	g=Grocery.objects.all()
	e=Entertainment.objects.all()
	edu=Education.objects.all()
	f=Food.objects.all()
	v=Vehicle.objects.all()
	p=Parties.objects.all()
	m=Miscellaneous.objects.all()
#Initializing every categorie's amount to 0
	g_money=0
	e_money=0
	edu_money=0
	f_money=0
	v_money=0
	p_money=0
	m_money=0
	total_money=0
	today=date.today()
#Adding expenses to the particular user on daily basis
	for person in g:
		#Checking if today's date and the date on which the amount has been spent by the individual are equal
		if person.user==request.session['username'] and str(person.grocery_expense_date)==datetime.datetime.now().strftime ("%Y-%m-%d"):
			g_money=g_money+person.spent_money

	for person in e:
		if person.user==request.session['username'] and str(person.entertainment_expense_date)==datetime.datetime.now().strftime ("%Y-%m-%d"):
			e_money=e_money+person.spent_money
	
	for person in edu:
		if person.user==request.session['username'] and str(person.education_expense_date)==datetime.datetime.now().strftime ("%Y-%m-%d"):
			edu_money=edu_money+person.spent_money

	for person in f:
		if person.user==request.session['username'] and str(person.food_expense_date)==datetime.datetime.now().strftime ("%Y-%m-%d"):
			f_money=f_money+person.spent_money

	for person in v:
		if person.user==request.session['username'] and str(person.vehicle_expense_date)==datetime.datetime.now().strftime ("%Y-%m-%d"):
			v_money=v_money+person.spent_money

	for person in p:
		if person.user==request.session['username'] and str(person.parties_expense_date)==datetime.datetime.now().strftime ("%Y-%m-%d"):
			p_money=p_money+person.spent_money

	for person in m:
		if person.user==request.session['username'] and str(person.miscellaneous_expense_date)==datetime.datetime.now().strftime ("%Y-%m-%d"):
			m_money=m_money+person.spent_money

	total_money=g_money+e_money+edu_money+v_money+p_money+f_money+m_money

	template = loader.get_template('dailyreport.html')
	context ={'grocery_money':g_money,'entertainment_money':e_money,'education_money':edu_money,'name':request.session['username'],'food_money':f_money,'today':today,'vehicle_money':v_money,'parties_money':p_money,'miscellaneous_money':m_money,'total':total_money}
	return HttpResponse(template.render(context, request))
